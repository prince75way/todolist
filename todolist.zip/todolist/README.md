# Todo List Application

This is a Todo List application built with Node.js, Express, and TypeScript. The application allows users to create accounts, log in, create tasks, and manage their todo lists.

## Features

- User Signup
- User Login
- Task Creation
- Assign List to User (Admin)
- Update List Status


## Installation

1. Clone the repository:
    ```sh
    git clone https://github.com/yourusername/todolist.git
    cd todolist
    ```

2. Install dependencies:
    ```sh
    npm install
    ```

3. Set up environment variables:
    Create a [.env](http://_vscodecontentref_/4) file in the root directory and add the necessary environment variables.

4. Run the application:
    ```sh
    npm start
    ```

## API Endpoints

### User Routes

- **POST /login**
  - Description: Logs in a user.
  - Request Body: `{ "email": "user@example.com", "password": "password" }`

- **POST /signup**
  - Description: Creates a new user.
  - Request Body: `{ "name": "User", "email": "user@example.com", "password": "password" }`

### List Routes

- **POST /assign**
  - Description: Assigns a list to a user by the admin.
  - Request Body: `{ "listId": "list123", "userId": "user123" }`

- **PATCH /update-status**
  - Description: Updates the status of a list by the user.
  - Request Body: `{ "listId": "list123", "status": "completed" }`

## Contributing

Contributions are welcome! Please open an issue or submit a pull request for any changes.

## License

This project is licensed under the MIT License.