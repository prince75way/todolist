import express from "express";
import userRoutes from './routes/user/user.route'
import listRoutes from './routes/list/list.route'

// routes
const router = express.Router();

router.use("/user", userRoutes);
router.use("/list", listRoutes);

export default router;