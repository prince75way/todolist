
import { Router } from "express";
import { catchError } from "../../middlewares/catcherror.middleware";

import * as userValidator from './user.validation'
import * as userController from './user.controller'


const router = Router();

router

.post("/login", userValidator.loginUser, catchError, userController.loginUser)
.post("/signup", userValidator.createUser, catchError, userController.createUser)

        
        //Login
        //Signup
        //Task Creation
        

export default router;

