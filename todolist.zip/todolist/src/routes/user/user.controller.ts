import asyncHandler from "express-async-handler";
import { type Request, type Response } from 'express';
import * as userService from './user.service';
import userSchema from "./user.schema";
import { error } from "console";

/**
 * Creates a new user.
 * 
 * @param {Request} req - The request object containing user details in the body.
 * @param {Response} res - The response object to send the result.
 * @returns {Promise<void>} - A promise that resolves to void.
 */
export const createUser = asyncHandler(async (req: Request, res: Response): Promise<void> => {
    console.log("requestbody is: ", req.body);
    const result = await userService.createUser(req.body);
    res.send();
});

/**
 * Logs in a user.
 * 
 * @param {Request} req - The request object containing login details in the body.
 * @param {Response} res - The response object to send the result.
 * @returns {Promise<void>} - A promise that resolves to void.
 */
export const loginUser = asyncHandler(async (req: Request, res: Response): Promise<void> => {
    const result = await userService.loginUser(req.body);
    res.send();
});