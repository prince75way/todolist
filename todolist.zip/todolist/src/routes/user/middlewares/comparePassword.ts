import { Request, Response, NextFunction } from 'express';
import bcrypt from 'bcrypt';
import createHttpError from 'http-errors';
import userSchema from '../user.schema';

export const comparePassword = (data:any) => {
  return async (req: Request, res: Response, next: NextFunction) => {
    try {
      // Extract the email and password from the request body
     const[email,password]=data;

      // Check if email and password were provided
      if (!email || !password) {
        throw createHttpError(400, 'Email and password are required');
      }

      // Fetch the user from MongoDB by email
      const user = await userSchema.findOne({ email });

      // If user is not found, throw a 404 error
      if (!user) {
        throw createHttpError(404, 'User not found');
      }

      // Compare the entered password with the hashed password stored in MongoDB
      const isPasswordMatch = await bcrypt.compare(password, user.password);

      // If passwords do not match, throw a 401 Unauthorized error
      if (!isPasswordMatch) {
        throw createHttpError(401, 'Invalid password');
      }


      // Proceed to the next middleware or route handler
      next();
    } catch (error) {
      next(error); // Pass any errors to the error handling middleware
    }
  };
};
