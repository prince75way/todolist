
import { error } from "console";
import { type IUser } from "./user.dto";
import userSchema from "./user.schema";
import { comparePassword } from "./middlewares/comparePassword";


export const createUser = async (data:IUser) => {
   const check=await userSchema.find({email:data.email});

   if(check){
    throw error("already existing email")
   }
    const result = await userSchema.create({ ...data });
    return result;
};

export const loginUser = async (data:IUser) => {
    const result=await comparePassword(data);
    return result;
 };

