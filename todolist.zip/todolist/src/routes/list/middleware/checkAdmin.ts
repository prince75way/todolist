// import { type Request, type Response, type NextFunction } from 'express';
// import createHttpError from 'http-errors';
// import userSchema from '../../user/user.schema';

// // Middleware to check if the user has an 'admin' role
// export const checkAdminRole = async(req: Request, res: Response, next: NextFunction) => {
//   try {
//     // Assuming the user role is stored in req.user after authentication

//     const email=req.body.email;

//     const user= await userSchema.find({email:email})
    

//     if (user.role !== 'ADMIN') {
//       throw createHttpError(403, 'Only admin can do this');
//     }

//     next(); // If user is an admin, proceed to the next middleware or route handler
//   } catch (error) {
//     next(error);
//   }
// };
