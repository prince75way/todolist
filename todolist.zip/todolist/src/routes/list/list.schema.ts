import mongoose, { Schema, Document } from 'mongoose';
import userSchema from '../user/user.schema';// Import the User model

// Define the TodoList schema (with a direct reference to the User model)
const todoListSchema = new Schema({
  title: { type: String, required: true },
  assignedTo: { type: mongoose.Schema.Types.ObjectId, ref: 'user', required: true },  // Reference to User model
  status: { 
    type: String, 
    enum: ['pending', 'completed'], 
    default: 'pending', 
    required: true 
  },
  timestamp: { type: Date, default: Date.now },  // Automatically set the current date and time when the task is created
});

// Create the TodoList model
const TodoList = mongoose.model('TodoList', todoListSchema);

export { TodoList };
