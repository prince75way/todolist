import { Router } from 'express';
import * as listValidator from './list.validation'
import * as listController from './list.controller';
import { catchError } from '../../middlewares/catcherror.middleware';

const router = Router();

router
  .post("/assign", listValidator.assignList, catchError, listController.assignList)
  .patch("/update-status", listValidator.updateListStatus, catchError, listController.updateListStatus);

export default router;