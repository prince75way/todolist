import { body } from 'express-validator';

export const assignList = [
  body('listId').isString().withMessage('List ID is required'),
  body('userId').isString().withMessage('User ID is required'),
];

export const updateListStatus = [
  body('listId').isString().withMessage('List ID is required'),
  body('status').isString().withMessage('Status is required'),
];